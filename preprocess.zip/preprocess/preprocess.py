import pandas as pd
import numpy as np
from pathlib import Path
import random

# npz 파일과 csv 파일을 읽어 딕셔너리로 반환하는 함수 

def dataToDict(csv_path: str, npz_dir: str) -> dict:

    # csv_path : csv 파일의 경로로
    # npz_dir : npz 파일이 들어있는 디렉토리 경로

    # 1) CSV 읽기 (track_id 문자열)
    df = pd.read_csv(Path(csv_path), dtype={'track_id': str})

    # 2) npz 디렉토리 Path 객체
    base = Path(npz_dir)

    data_dict = {}
    for _, row in df.iterrows():
        raw_tid    = row['track_id']
        padded_tid = raw_tid.zfill(6)            # '134' → '000134'
        npz_file   = base / f"{padded_tid}.npz"  

        if not npz_file.is_file():
            print(f"[Warning] {npz_file.name} not found. skipping.")
            continue

        try:
            with np.load(npz_file) as archive:
                features = archive['hyper'].astype(np.float32)
        except Exception as e:
            print(f"[Error] {padded_tid}: npz load failed ({e})")
            continue

        data_dict[padded_tid] = {
            'tid':        raw_tid,                # 음원 id
            'features':   features,               # 하이퍼이미지 배열의 형태 (628, 1287)
            'genre_top':  row['track_genre_top'], # 장르 레이블
            'split':      row['set_split'],       # test/train/validation 여부
        }

    print(f"Loaded {len(data_dict)} / {len(df)} tracks")
    return data_dict

if __name__ == "__main__":
    csv_file   = 'track.csv'
    npz_folder = 'arrays'
    tracks = dataToDict(csv_file, npz_folder)

    err = 0
    for tid, info in tracks.items():
        if info['features'].shape != (628, 1287):
            print(f"{tid}: {info['features'].shape}")
            err += 1
    print('error count :', err) if err else print('no error')

    # sample_items = random.sample(list(tracks.items()), 5)

    # for tid, info in sample_items:
    #     shape = info['features'].shape
    #     genre = info['genre_top']
    #     split = info['split']
    #     print(tid, shape, genre, split)
